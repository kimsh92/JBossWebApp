#!/bin/bash

source ./setup_to_install_ocp4_step00_set_variables.sh

SELINUX_STATUS=$(getenforce)
#echo ${SELINUX_STATUS}
GREP_RESULT=$(getenforce)
if [ -z "$(echo "${GREP_RESULT}" | grep "Disabled")" ]
then
    sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config 
    echo "SELINUX is disabled, system is restarting now"
    reboot
fi

echo "mv config files"
cp named.conf /etc/
cp named.rfc1912.zones /etc/
cp $BASE_DOMAIN.zone /var/named/
cp haproxy.cfg /etc/haproxy/

echo "systemctl disable --now firewalld"
systemctl disable --now firewalld

echo "systemctl enable --now named"
systemctl enable --now named

echo "systemctl enable --now httpd"
systemctl enable --now httpd
systemctl start httpd

echo "systemctl enable --now haproxy"
systemctl enable --now haproxy
systemctl start haproxy


