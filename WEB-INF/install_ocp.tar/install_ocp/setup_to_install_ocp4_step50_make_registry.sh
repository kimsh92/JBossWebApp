#!/bin/bash

source ./setup_to_install_ocp4_step00_set_variables.sh

echo "IS_RESTRICTED_ENV=${IS_RESTRICTED_ENV}"
echo "MIRROR_REPOSITORY_COPY_TO_PATH=${MIRROR_REPOSITORY_COPY_TO_PATH}
echo "MIRROR_REPOSITORY_URL=${MIRROR_REPOSITORY_URL}
echo "pull-secret: ${PULL_SECRET}"

#===============================================================================

if [ "$IS_RESTRICTED_ENV" != true ]
then
    echo "The value of IS_RESTRICTED_ENV is set as false, so creating mirror registry is skipped!"
    exit
fi


# Process Arguments
while [[ $# -gt 0 ]]
do
key="$1"
case $key in
    -o|--ocp-version)
    OCP_VERSION="$2"
    shift
    shift
    ;;
    -m|--masters)
    MASTERS="$2"
    shift
    shift
    ;;
    *)
    echo "ERROR: Invalid argument $key"
    exit 1
    ;;
esac
done

# Default Values
echo "OCP Version: ${OCP_VERSION}"

err() {
    echo; echo;
    echo -e "[Error] ${1}"; shift; echo;
    while [[ $# -gt 0 ]]; do echo "    $1"; shift; done
    echo; exit 1;
}

ok() {
    test -z "$1" && echo "ok" || echo "$1"
}

if test -z "$OCP_VERSION"
then
   err "\$OCP_VERSION is empty"
fi

echo "--------------------------------------------------------------------------------------"

hostnamectl set-hostname ${BASTION_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN} 

mkdir -p /opt/registry/{auth,data,certs}

cd /opt/registry/certs

#openssl req -newkey rsa:4096 -nodes -sha256 -keyout domain.key -x509 -days 36500 -out domain.crt
echo "openssl req -newkey rsa:4096 -nodes -sha256 -keyout domain.key -x509 -days 36500 -out domain.crt -subj '/C=KR/ST=Seoul/L=Gangnam/O=Redhat/OU=GPS/CN=${BASTION_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN}'"

openssl req -newkey rsa:4096 -nodes -sha256 -keyout domain.key -x509 -days 36500 -out domain.crt -subj '/C=KR/ST=Seoul/L=Gangnam/O=Redhat/OU=GPS/CN='${BASTION_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN}

echo "cp /opt/registry/certs/domain.crt /etc/pki/ca-trust/source/anchors/"
cp /opt/registry/certs/domain.crt /etc/pki/ca-trust/source/anchors/

echo "update-ca-trust extract"
update-ca-trust extract

echo ${PULL_SECRET} > /opt/registry/pull-secret

echo "run mirror-registry"

podman rm mirror-registry -f > /dev/null

podman pull docker.io/library/registry:2

podman run --rm --name mirror-registry -p 5000:5000 \
-v /opt/registry/data:/var/lib/registry:z \
-v /opt/registry/certs/:/certs:z \
-e REGISTRY_HTTP_TLS_CERTIFICATE=/certs/domain.crt \
-e REGISTRY_HTTP_TLS_KEY=/certs/domain.key \
-d docker.io/library/registry:2

echo "mirror registry"
OCP_RELEASE="${OCP_VERSION}-x86_64"
LOCAL_REGISTRY="${BASTION_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN}:5000"
LOCAL_REPOSITORY='ocp4/openshift4'
PRODUCT_REPO='openshift-release-dev'
RELEASE_NAME="ocp-release"
LOCAL_SECRET_JSON=/opt/registry/pull-secret

echo "oc adm -a ${LOCAL_SECRET_JSON} release mirror \
--from=quay.io/${PRODUCT_REPO}/${RELEASE_NAME}:${OCP_RELEASE} \
--to=${LOCAL_REGISTRY}/${LOCAL_REPOSITORY} \
--to-release-image=${LOCAL_REGISTRY}/${LOCAL_REPOSITORY}:${OCP_RELEASE}"

oc adm -a ${LOCAL_SECRET_JSON} release mirror \
--from=quay.io/${PRODUCT_REPO}/${RELEASE_NAME}:${OCP_RELEASE} \
--to=${LOCAL_REGISTRY}/${LOCAL_REPOSITORY} \
--to-release-image=${LOCAL_REGISTRY}/${LOCAL_REPOSITORY}:${OCP_RELEASE}


if [ "$IS_INITIAL_SETUP" = true ]
then
  htpasswd -bBc /opt/registry/auth/htpasswd admin admin
fi

echo "create /workdir/pull-secret"
mkdir /workdir
TEMP=$(echo -n 'admin:admin' | base64 -w0)
echo '{"auths":{"${BASTION_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN}:5000":{"auth":"'$TEMP'","email":"${PULL_SECRET_EMAIL}"}}}' > /workdir/pull-secret

echo "run mirror-registry"
podman rm mirror-registry -f

podman run --name mirror-registry -p 5000:5000 \
-v /opt/registry/data:/var/lib/registry:z \
-v /opt/registry/auth:/auth:z \
-e "REGISTRY_AUTH=htpasswd" \
-e "REGISTRY_AUTH_HTPASSWD_REALM=Registry Realm" \
-e "REGISTRY_HTTP_SECRET=ALongRandomSecretForRegistry" \
-e REGISTRY_AUTH_HTPASSWD_PATH=/auth/htpasswd \
-v /opt/registry/certs:/certs:z \
-e REGISTRY_HTTP_TLS_CERTIFICATE=/certs/domain.crt \
-e REGISTRY_HTTP_TLS_KEY=/certs/domain.key \
-d docker.io/library/registry:2

if [ "$IS_INITIAL_SETUP" = true ]
then
  echo "ssh-keygen"
  rm /root/.ssh/id_rsa -f
  ssh-keygen -t rsa -b 4096 -P "" -f /root/.ssh/id_rsa
fi
