#!/bin/bash

source ./setup_to_install_ocp4_step00_set_variables.sh

###############################################################
# /var/named/BASE_DOMAIN.zone

echo "\$TTL 1D
@	IN SOA		@ ns.${BASE_DOMAIN}. (
					0	; serial
					1D	; refresh
					1H	; retry
					1W	; expire
					3H )	; minimum
@		IN NS	ns.${BASE_DOMAIN}.
@		IN A	${BASTION_IP}

; Ancillary services
lb.${CLUSTER_NAME}		IN A	${BASTION_IP}

; Bastion or Jumphost
bastion.${CLUSTER_NAME}	IN A	${BASTION_IP}
ns		IN A	${BASTION_IP}

; OCP Cluster
${BOOTSTRAP_HOSTNAME}.${CLUSTER_NAME}	IN A	${BOOTSTRAP_IP}
${MASTER_HOSTNAMES[0]}.${CLUSTER_NAME}	IN A	${MASTER_IPS[0]}
${MASTER_HOSTNAMES[1]}.${CLUSTER_NAME}	IN A	${MASTER_IPS[1]}
${MASTER_HOSTNAMES[2]}.${CLUSTER_NAME}	IN A	${MASTER_IPS[2]}
" > ${BASE_DOMAIN}.zone

for (( i = 0 ; i < ${#WORKER_IPS[@]} ; i=$i+1 ));
do
    echo "${WORKER_HOSTNAMES[${i}]}.${CLUSTER_NAME}	IN A	${WORKER_IPS[${i}]}" >> ${BASE_DOMAIN}.zone
done

echo "
etcd-0.${CLUSTER_NAME}	IN A	${MASTER_IPS[0]}
etcd-1.${CLUSTER_NAME}	IN A	${MASTER_IPS[1]}
etcd-2.${CLUSTER_NAME}	IN A	${MASTER_IPS[2]}

_etcd-server-ssl._tcp.${CLUSTER_NAME}.${BASE_DOMAIN}.	IN SRV  0   10   2380    etcd-0.${CLUSTER_NAME}.${BASE_DOMAIN}.
					IN SRV  0   10   2380    etcd-1.${CLUSTER_NAME}.${BASE_DOMAIN}.
					IN SRV  0   10   2380    etcd-2.${CLUSTER_NAME}.${BASE_DOMAIN}.

api.${CLUSTER_NAME}	IN A	${BASTION_IP}  ; external LB interface
api-int.${CLUSTER_NAME}	IN A	${BASTION_IP}  ; internal LB interface
apps.${CLUSTER_NAME}	IN A	${BASTION_IP} 
*.apps.${CLUSTER_NAME}	IN A	${BASTION_IP}
" >> ${BASE_DOMAIN}.zone

##########################################################################
# /etc/haproxy/haproxy.cfg

echo "#---------------------------------------------------------------------
# Example configuration for a possible web application.  See the
# full configuration options online.
#
#   http://haproxy.1wt.eu/download/1.4/doc/configuration.txt
#
#---------------------------------------------------------------------

#---------------------------------------------------------------------
# Global settings
#---------------------------------------------------------------------
global
    # to have these messages end up in /var/log/haproxy.log you will
    # need to:
    #
    # 1) configure syslog to accept network log events.  This is done
    #    by adding the '-r' option to the SYSLOGD_OPTIONS in
    #    /etc/sysconfig/syslog
    #
    # 2) configure local2 events to go to the /var/log/haproxy.log
    #   file. A line like the following can be added to
    #   /etc/sysconfig/syslog
    #
    #    local2.*                       /var/log/haproxy.log
    #
    log         127.0.0.1 local2

    chroot      /var/lib/haproxy
    pidfile     /var/run/haproxy.pid
    maxconn     4000
    user        haproxy
    group       haproxy
    daemon

    # turn on stats unix socket
    stats socket /var/lib/haproxy/stats

#---------------------------------------------------------------------
# common defaults that all the 'listen' and 'backend' sections will
# use if not designated in their block
#---------------------------------------------------------------------
defaults
    mode                    http
    log                     global
    option                  httplog
    option                  dontlognull
    option http-server-close
    option forwardfor       except 127.0.0.0/8
    option                  redispatch
    retries                 3
    timeout http-request    10s
    timeout queue           1m
    timeout connect         10s
    timeout client          1m
    timeout server          1m
    timeout http-keep-alive 10s
    timeout check           10s
    maxconn                 3000

#---------------------------------------------------------------------
# OpenShift
#---------------------------------------------------------------------

frontend openshift-api-server
    bind *:6443
    default_backend openshift-api-server
    mode tcp
    option tcplog

backend openshift-api-server
    balance source
    mode tcp
    server ${BOOTSTRAP_HOSTNAME} ${BOOTSTRAP_IP}:6443 check
    server ${MASTER_HOSTNAMES[0]} ${MASTER_IPS[0]}:6443 check
    server ${MASTER_HOSTNAMES[1]} ${MASTER_IPS[1]}:6443 check
    server ${MASTER_HOSTNAMES[2]} ${MASTER_IPS[2]}:6443 check

frontend machine-config-server
    bind *:22623
    default_backend machine-config-server
    mode tcp
    option tcplog

backend machine-config-server
    balance source
    mode tcp
    server ${BOOTSTRAP_HOSTNAME} ${BOOTSTRAP_IP}:22623 check
    server ${MASTER_HOSTNAMES[0]} ${MASTER_IPS[0]}:22623 check
    server ${MASTER_HOSTNAMES[1]} ${MASTER_IPS[1]}:22623 check
    server ${MASTER_HOSTNAMES[2]} ${MASTER_IPS[2]}:22623 check

frontend ingress-http
    bind *:80
    default_backend ingress-http
    mode tcp
    option tcplog

backend ingress-http
    balance source
    mode tcp" > haproxy.cfg
for (( i = 0 ; i < ${#WORKER_IPS[@]} ; i=$i+1 ));
do
    echo "    server ${WORKER_HOSTNAMES[${i}]} ${WORKER_IPS[${i}]}:80 check" >> haproxy.cfg
done
echo "
frontend ingress-https
    bind *:443
    default_backend ingress-https
    mode tcp
    option tcplog

backend ingress-https
    balance source
    mode tcp" >> haproxy.cfg
for (( i = 0 ; i < ${#WORKER_IPS[@]} ; i=$i+1 ));
do
    echo "    server ${WORKER_HOSTNAMES[${i}]} ${WORKER_IPS[${i}]}:443 check" >> haproxy.cfg
done


######################################################################
# /etc/named.conf


echo '//
// named.conf
//
// Provided by Red Hat bind package to configure the ISC BIND named(8) DNS
// server as a caching only nameserver (as a localhost DNS resolver only).
//
// See /usr/share/doc/bind*/sample/ for example named configuration files.
//
// See the BIND Administrator'\''s Reference Manual (ARM) for details about the
// configuration located in /usr/share/doc/bind-{version}/Bv9ARM.html

options {
        listen-on port 53 { any; };
        listen-on-v6 port 53 { none; };
        directory       "/var/named";
        dump-file       "/var/named/data/cache_dump.db";
        statistics-file "/var/named/data/named_stats.txt";
        memstatistics-file "/var/named/data/named_mem_stats.txt";
        recursing-file  "/var/named/data/named.recursing";
        secroots-file   "/var/named/data/named.secroots";
        allow-query     { any; };

        /*
         - If you are building an AUTHORITATIVE DNS server, do NOT enable recursion.
         - If you are building a RECURSIVE (caching) DNS server, you need to enable
           recursion.
         - If your recursive DNS server has a public IP address, you MUST enable access
           control to limit queries to your legitimate users. Failing to do so will
           cause your server to become part of large scale DNS amplification
           attacks. Implementing BCP38 within your network would greatly
           reduce such attack surface
        */
        recursion yes;

        forward only;
        forwarders {
                168.126.63.1;   // 상위 DNS 설정 (외부 네트워크를 위한)

        };

        dnssec-enable yes;
        dnssec-validation no;  // yes -> no로 변경

        /* Path to ISC DLV key */
        bindkeys-file "/etc/named.root.key";

        managed-keys-directory "/var/named/dynamic";

        pid-file "/run/named/named.pid";
        session-keyfile "/run/named/session.key";
        check-names master ignore;
};

logging {
        channel default_debug {
                file "data/named.run";
                severity dynamic;
        };
};

zone "." IN {
        type hint;
        file "named.ca";
};

include "/etc/named.rfc1912.zones";
include "/etc/named.root.key";' > named.conf


echo '// named.rfc1912.zones:
//
// Provided by Red Hat caching-nameserver package
//
// ISC BIND named zone configuration for zones recommended by
// RFC 1912 section 4.1 : localhost TLDs and address zones
// and http://www.ietf.org/internet-drafts/draft-ietf-dnsop-default-local-zones-02.txt
// (c)2007 R W Franks
//
// See /usr/share/doc/bind*/sample/ for example named configuration files.
//

zone "localhost.localdomain" IN {
        type master;
        file "named.localhost";
        allow-update { none; };
};

zone "localhost" IN {
        type master;
        file "named.localhost";
        allow-update { none; };
};

zone "1.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.0.ip6.arpa" IN {
        type master;
        file "named.loopback";
        allow-update { none; };
};

zone "1.0.0.127.in-addr.arpa" IN {
        type master;
        file "named.loopback";
        allow-update { none; };
};

zone "0.in-addr.arpa" IN {
        type master;
        file "named.empty";
        allow-update { none; };
};

zone "'$BASE_DOMAIN'" IN {
        type master;
        file "/var/named/'$BASE_DOMAIN.zone'";
        allow-update { none; };
};' > named.rfc1912.zones
