#!/bin/bash

echo "rpm  --import /etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release"
rpm  --import /etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release     

echo "subscription-manager register"
subscription-manager register

echo "subscription-manager attach --pool=8a85f99b6b498682016b521dfe463949"
subscription-manager attach --pool=8a85f99b6b498682016b521dfe463949

echo "--------------------------------------------------------------------------------------"
echo "subscription-manager repos --disable=*"
subscription-manager repos --disable=*

echo "subscription-manager repos  --enable=rhel-7-server-rpms --enable=rhel-7-server-extras-rpms --enable=rhel-7-server-ansible-2.8-rpms --enable=rhel-7-server-ose-4.3-rpms"
subscription-manager repos  --enable=rhel-7-server-rpms --enable=rhel-7-server-extras-rpms --enable=rhel-7-server-ansible-2.8-rpms --enable=rhel-7-server-ose-4.3-rpms
