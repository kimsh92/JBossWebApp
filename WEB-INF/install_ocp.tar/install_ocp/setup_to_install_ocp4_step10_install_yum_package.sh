#!/bin/bash

yum -y install net-tools wget vim bind bind-utils haproxy httpd httpd-tools podman  jq 

