#!/bin/bash
#title           :setup_to_install_ocp4_step6_make_install_config.sh
#description     :This script will check conditions and create files to install the OCP 4.
#author		 :Eunsoo Jung (ejung@redhat.com)
#date            :20200522
#version         :0.1    
#usage		 :bash setup_to_install_ocp4_step6_make_install_config.sh 
#==============================================================================

#===============================================================================

source ./setup_to_install_ocp4_step00_set_variables.sh

# Process Arguments
while [[ $# -gt 0 ]]
do
key="$1"
case $key in
    -o|--ocp-version)
    OCP_VERSION="$2"
    shift
    shift
    ;;
    -m|--masters)
    MASTERS="$2"
    shift
    shift
    ;;
    *)
    echo "ERROR: Invalid argument $key"
    exit 1
    ;;
esac
done

# Default Values
test -z "$MASTERS" && MASTERS="3"

echo "OCP Version: ${OCP_VERSION}"
echo "Master count: ${MASTERS}"

echo "$PULL_SECRET" > $PULL_SECRET_FILE

err() {
    echo; echo;
    echo -e "[Error] ${1}"; shift; echo;
    while [[ $# -gt 0 ]]; do echo "    $1"; shift; done
    echo; exit 1;
}

ok() {
    test -z "$1" && echo "ok" || echo "$1"
}

if test -z "$OCP_VERSION" 
then
   err "\$OCP_VERSION is empty"
fi

# check root 
test "$(whoami)" = "root" || err "Not running as root"

echo -n "====> Checking if httpd is running: "
#sleep 0.3
systemctl -q is-active httpd || err "httpd is not running"; ok

echo -n "====> Checking if named is running: "
#sleep 0.3
systemctl -q is-active named || err "named is not running"; ok

echo -n "====> Checking if haproxy is running: "
#sleep 0.3
systemctl -q is-active haproxy || err "haproxy is not running"; ok
	
echo -n "====> Checking if NetworkManager is running: "
#sleep 0.3
systemctl -q is-active NetworkManager || err "NetworkManager is not running"; ok

echo -n "====> Checking if SELINUX is Disabled: "
#sleep 0.3
SELINUX_STATUS=$(getenforce)
#echo ${SELINUX_STATUS}
test "${SELINUX_STATUS}" = "Disabled" || err "SELINUX is not Disabled"; ok

echo -n "====> Checking if necessary ports are opened(8080,443,5443,22623): "
#sleep 0.3
STATUS=$(systemctl is-active firewalld)
if [ "$STATUS" != "active" ]
then
    ok "ok, firewalld is not running"
else
    FIREWALL_PORTS=$(firewall-cmd --list-ports)
    if [ -z "$(echo "${FIREWALL_PORTS}" | grep "8080/tcp")" ]
    then
        err "port 8080 is not opened"
    fi
    if [ -z "$(echo "${FIREWALL_PORTS}" | grep "443/tcp")" ]
    then
        err "port 443 is not opened"
    fi
    if [ -z "$(echo "${FIREWALL_PORTS}" | grep "6443/tcp")" ]
    then
        err "port 5443 is not opened"
    fi
    if [ -z "$(echo "${FIREWALL_PORTS}" | grep "22623/tcp")" ]
    then
        err "port 22623 is not opened"
    fi
    ok
fi

echo -n "====> Checking if $PULL_SECRET_FILE exists: "
if [ -f "$PULL_SECRET_FILE" ]
then
    PULL_SECRET="$(cat $PULL_SECRET_FILE)"
    echo "$PULL_SECRET" | jq '.auths += '"$(cat /workdir/pull-secret | jq '.auths')" > temp.txt
    PULL_SECRET="$(cat temp.txt | jq -c)"
    #echo $PULL_SECRET
    #echo $PULL_SECRET | jq
    rm -f temp.txt
    ok
else
    err "$PULL_SECRET_FILE doesn't exist"
fi

echo -n "====> Checking if /root/.ssh/id_rsa.pub exists: "
if [ -f "/root/.ssh/id_rsa.pub" ]
then
    ok
else
    err "/root/.ssh/id_rsa.pub doesn't exist"
fi

echo -n "====> Checking if /opt/registry/certs/domain.crt exists: "
if [ -f "/opt/registry/certs/domain.crt" ]
then
    ok
else
    err "/opt/registry/certs/domain.crt doesn't exist"
fi
cp /opt/registry/certs/domain.crt /opt/registry/certs/domain.crt.temp
sed -i -e 's/^/  /' /opt/registry/certs/domain.crt.temp
DOMAIN_CRT=$(cat /opt/registry/certs/domain.crt.temp)
rm -f /opt/registry/certs/domain.crt.temp

echo -n "====> Checking if $OCP_PATH already exists: "
if [ -d "$OCP_PATH" ]
then
    err "Directory $OCP_PATH already exists"
else
    ok
fi


echo -n "====> Checking if openshift-install-linux-${OCP_VERSION}.tar.gz exists: "
test -f openshift-install-linux-${OCP_VERSION}.tar.gz || err "openshift-install-linux-${OCP_VERSION}.tar.gz doesn't exist";ok 
tar -xzf openshift-install-linux-${OCP_VERSION}.tar.gz -C /usr/local/bin/

echo -n "====> Checking if openshift-client-linux-${OCP_VERSION}.tar.gz exists: "
test -f openshift-client-linux-${OCP_VERSION}.tar.gz || err "openshift-client-linux-${OCP_VERSION}.tar.gz doesn't exist";ok 
tar -xzf openshift-client-linux-${OCP_VERSION}.tar.gz -C /usr/local/bin/





echo -n "====> Creating install-config.yaml : "
mkdir $OCP_PATH
cat <<EOF > $OCP_PATH/install-config.yaml
apiVersion: v1
baseDomain: ${BASE_DOMAIN}
compute:
- hyperthreading: Enabled
  name: worker
  replicas: 0
controlPlane:
  hyperthreading: Enabled
  name: master
  replicas: ${MASTERS}
metadata:
  name: ${CLUSTER_NAME}
networking:
  clusterNetwork:
  - cidr: 10.128.0.0/14
    hostPrefix: 23
  networkType: OpenShiftSDN
  serviceNetwork:
  - 172.30.0.0/16
platform:
  none: {}
pullSecret: '${PULL_SECRET}'
sshKey: '$(cat /root/.ssh/id_rsa.pub)'
additionalTrustBundle: |
${DOMAIN_CRT}
imageContentSources:
- mirrors:
  - ${BASTION_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN}:5000/ocp4/openshift4
  source: quay.io/openshift-release-dev/ocp-release
- mirrors:
  - ${BASTION_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN}:5000/ocp4/openshift4
  source: quay.io/openshift-release-dev/ocp-v4.0-art-dev
EOF
ok

echo -n "====> Creating template files: "
cat <<EOF > $OCP_PATH/ign.template
{
  "storage": {
    "files": [
      {
        "contents": {
          "source": "data:text/plain;charset=utf-8,HOSTNAME_SOURCE",
          "verification": {}
        },
        "filesystem": "root",
        "group": {},
        "mode": 420,
        "path": "/etc/hostname",
        "user": {}
      },
      {
        "contents": {
          "source": "data:text/plain;charset=utf-8;base64,CHRONY_SOURCE",
          "verification": {}
        },
        "filesystem": "root",
        "path": "/etc/chrony.conf",
        "mode": 420,
        "user": {}
      }
    ]
  }
}
EOF
cat <<EOF > $OCP_PATH/chrony.conf.template
pool CHRONY_SERVER_IP iburst
driftfile /var/lib/chrony/drift
makestep 1.0 3
rtcsync
keyfile /etc/chrony.keys
leapsectz right/UTC
logdir /var/log/chrony
EOF
mkdir ${OCP_PATH}/ign
cd ${OCP_PATH}
cp install-config.yaml install-config.yaml.bak
ok

openshift-install create manifests --dir=${OCP_PATH}
cp install-config.yaml.bak install-config.yaml

sed -i 's/mastersSchedulable: true/mastersSchedulable: false/g' manifests/cluster-scheduler-02-config.yml
#cp manifests/cluster-scheduler-02-config.yml cluster-scheduler-02-config.yml
openshift-install create ignition-configs --dir=${OCP_PATH}
cp ${OCP_PATH}/chrony.conf.template ${OCP_PATH}/chrony.conf
sed -i 's/CHRONY_SERVER_IP/'"${CHRONY_SERVER_IP}"'/g' ${OCP_PATH}/chrony.conf
#cat ${OCP_PATH}/chrony.conf
CHRONY_SOURCE="$(cat ${OCP_PATH}/chrony.conf | base64 -w0)"
#echo $CHRONY_SOURCE

cp ${OCP_PATH}/ign.template ${OCP_PATH}/ign/
sed -i 's/HOSTNAME_SOURCE/'"${BOOTSTRAP_HOSTNAME}.${CLUSTER_NAME}.${BASE_DOMAIN}"'/g' ${OCP_PATH}/ign/ign.template
sed -i 's/CHRONY_SOURCE/'"${CHRONY_SOURCE}"'/g' ${OCP_PATH}/ign/ign.template
#jq -s add ${OCP_PATH}/bootstrap.ign ${OCP_PATH}/ign/ign.template > ${OCP_PATH}/ign/bs.ign
EXTRACTED="$(cat ${OCP_PATH}/ign/ign.template | jq '.storage.files')"
#echo $EXTRACTED
cat ${OCP_PATH}/bootstrap.ign | jq '.storage.files += '"$EXTRACTED"'' > ${OCP_PATH}/ign/bs.ign

cp ${OCP_PATH}/ign.template ${OCP_PATH}/ign/
sed -i 's/HOSTNAME_SOURCE/'"${MASTER_HOSTNAMES[0]}.${CLUSTER_NAME}.${BASE_DOMAIN}"'/g' ${OCP_PATH}/ign/ign.template
sed -i 's/CHRONY_SOURCE/'"${CHRONY_SOURCE}"'/g' ${OCP_PATH}/ign/ign.template
jq -s add ${OCP_PATH}/master.ign ${OCP_PATH}/ign/ign.template > ${OCP_PATH}/ign/m1.ign

cp ${OCP_PATH}/ign.template ${OCP_PATH}/ign/
sed -i 's/HOSTNAME_SOURCE/'"${MASTER_HOSTNAMES[1]}.${CLUSTER_NAME}.${BASE_DOMAIN}"'/g' ${OCP_PATH}/ign/ign.template
sed -i 's/CHRONY_SOURCE/'"${CHRONY_SOURCE}"'/g' ${OCP_PATH}/ign/ign.template
jq -s add ${OCP_PATH}/master.ign ${OCP_PATH}/ign/ign.template > ${OCP_PATH}/ign/m2.ign

cp ${OCP_PATH}/ign.template ${OCP_PATH}/ign/
sed -i 's/HOSTNAME_SOURCE/'"${MASTER_HOSTNAMES[2]}.${CLUSTER_NAME}.${BASE_DOMAIN}"'/g' ${OCP_PATH}/ign/ign.template
sed -i 's/CHRONY_SOURCE/'"${CHRONY_SOURCE}"'/g' ${OCP_PATH}/ign/ign.template
jq -s add ${OCP_PATH}/master.ign ${OCP_PATH}/ign/ign.template > ${OCP_PATH}/ign/m3.ign
echo "TTTTTTT"
for (( i = 0 ; i < ${#WORKER_IPS[@]} ; i=$i+1 ));
do
  num=$(($i+1))
  cp ${OCP_PATH}/ign.template ${OCP_PATH}/ign/
  sed -i 's/HOSTNAME_SOURCE/'"${WORKER_HOSTNAMES[${i}]}.${CLUSTER_NAME}.${BASE_DOMAIN}"'/g' ${OCP_PATH}/ign/ign.template
  sed -i 's/CHRONY_SOURCE/'"${CHRONY_SOURCE}"'/g' ${OCP_PATH}/ign/ign.template
  jq -s add ${OCP_PATH}/worker.ign ${OCP_PATH}/ign/ign.template > ${OCP_PATH}/ign/w${num}.ign
done

rm ${OCP_PATH}/ign.template
rm ${OCP_PATH}/ign/ign.template
rm ${OCP_PATH}/chrony.conf.template
rm ${OCP_PATH}/chrony.conf


