#!/bin/bash

source ./setup_to_install_ocp4_step00_set_variables.sh


OPENSHIFT_CLIENT=openshift-client-linux-${OCP_VERSION}.tar.gz
OPENSHIFT_INSTALL=openshift-install-linux-${OCP_VERSION}.tar.gz
OPENSHIFT_CLIENT_URL=https://mirror.openshift.com/pub/openshift-v4/clients/ocp/${OCP_VERSION}/${OPENSHIFT_CLIENT}
OPENSHIFT_INSTALL_URL=https://mirror.openshift.com/pub/openshift-v4/clients/ocp/${OCP_VERSION}/${OPENSHIFT_INSTALL}

if [ -f "$OPENSHIFT_CLIENT" ]
then
    echo "$OPENSHIFT_CLIENT is already exist, downloading will be skipped"
else
    wget $OPENSHIFT_CLIENT_URL
fi

if [ -f "$OPENSHIFT_INSTALL" ]
then
    echo "$OPENSHIFT_INSTALL is already exist, downloading will be skipped"
else
    wget $OPENSHIFT_INSTALL_URL
fi

tar xzf $OPENSHIFT_CLIENT -C /usr/local/bin/
