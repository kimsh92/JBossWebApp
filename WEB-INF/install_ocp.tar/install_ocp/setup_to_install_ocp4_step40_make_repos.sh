#!/bin/bash


source ./setup_to_install_ocp4_step00_set_variables.sh

echo "IS_RESTRICTED_ENV=${IS_RESTRICTED_ENV}"
echo "MIRROR_REPOSITORY_COPY_TO_PATH=${MIRROR_REPOSITORY_COPY_TO_PATH}
echo "MIRROR_REPOSITORY_URL=${MIRROR_REPOSITORY_URL}
echo "pull-secret: ${PULL_SECRET}"

if [ "$IS_RESTRICTED_ENV" != true ]
then
    echo "The value of IS_RESTRICTED_ENV is set as false, so creating mirror repository is skipped!"
    exit
fi

rm -f /etc/yum.repos.d/ocp.repo
yum repolist

echo "--------------------------------------------------------------------------------------"
echo "yum  -y install yum-utils createrepo"
yum  -y install yum-utils createrepo

echo "--------------------------------------------------------------------------------------"
echo "createrepo"
mkdir /var/repos
for repo in \
rhel-7-server-rpms \
rhel-7-server-extras-rpms \
rhel-7-server-ansible-2.8-rpms \
rhel-7-server-ose-4.3-rpms
do 
 reposync -n  --gpgcheck -l --repoid=${repo} --download_path=/var/repos    
 createrepo -v  /var/repos/${repo} -o /var/repos/${repo}   
done


#echo "--------------------------------------------------------------------------------------"
#echo "create repos.tar.gz"
#mkdir install_preparation
#tar cvfz install_preparation/repos.tar.gz /var/repos/

echo "Delete ${MIRROR_REPOSITORY_COPY_TO_PATH}"
rm -rf ${MIRROR_REPOSITORY_COPY_TO_PATH}
echo "Copy from /var/repos to ${MIRROR_REPOSITORY_COPY_TO_PATH}"
mkdir ${MIRROR_REPOSITORY_COPY_TO_PATH}
cp -R /var/repos/* ${MIRROR_REPOSITORY_COPY_TO_PATH}/


echo "yum repolist"
echo "[rhel-7-server-rpms]
name=rhel-7-server-rpms
baseurl=${MIRROR_REPOSITORY_URL}/rhel-7-server-rpms
enabled=1
gpgcheck=0

[rhel-7-server-extras-rpms]
name=rhel-7-server-extras-rpms
baseurl=${MIRROR_REPOSITORY_URL}/rhel-7-server-extras-rpms
enabled=1
gpgcheck=0

[rhel-7-server-ansible-2.8-rpms]
name=rhel-7-server-ansible-2.8-rpms
baseurl=${MIRROR_REPOSITORY_URL}/rhel-7-server-ansible-2.8-rpms
enabled=1
gpgcheck=0

[rhel-7-server-ose-4.3-rpms]
name=rhel-7-server-ose-4.3-rpms
baseurl=${MIRROR_REPOSITORY_URL}/rhel-7-server-ose-4.3-rpms
enabled=1
gpgcheck=0" > /etc/yum.repos.d/ocp.repo

yum repolist

GREP_RESULT=$(grep "Listen 8080" /etc/httpd/conf/httpd.conf)
if [ -z "$(echo "${GREP_RESULT}" | grep "Listen 8080")" ]
then
    sed -i 's/Listen 80/Listen 8080/g' /etc/httpd/conf/httpd.conf
    systemctl enable --now httpd
 
fi
